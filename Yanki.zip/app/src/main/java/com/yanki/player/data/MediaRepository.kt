package com.yanki.player.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media as AudioMedia
import android.provider.MediaStore.Video.Media as VideoMedia

object MediaRepository {
    private val ART_BASE: Uri = Uri.parse("content://media/external/audio/albumart")

    /** Cihaz hafızası ve SD karttaki tüm ses dosyaları (MediaStore otomatik tarar). */
    fun loadAudio(ctx: Context): List<MediaInfo> {
        val out = ArrayList<MediaInfo>()
                val proj = arrayOf(AudioMedia._ID, AudioMedia.TITLE, AudioMedia.ARTIST, AudioMedia.ALBUM, AudioMedia.ALBUM_ID, AudioMedia.DURATION, AudioMedia.DATA)
        val sel = "${AudioMedia.DURATION} >= 5000 AND ${AudioMedia.IS_RINGTONE} = 0 AND ${AudioMedia.IS_NOTIFICATION} = 0 AND ${AudioMedia.IS_ALARM} = 0"
        runCatching {
            ctx.contentResolver.query(
                AudioMedia.EXTERNAL_CONTENT_URI, proj, sel, null, "${AudioMedia.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(AudioMedia._ID)
                val iTitle = c.getColumnIndexOrThrow(AudioMedia.TITLE)
                val iArtist = c.getColumnIndexOrThrow(AudioMedia.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(AudioMedia.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(AudioMedia.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(AudioMedia.DURATION)
                val iData = c.getColumnIndexOrThrow(AudioMedia.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val artist = c.getString(iArtist)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "Bilinmeyen sanatçı"
                    val album = c.getString(iAlbum)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: ""
                    val albumId = c.getLong(iAlbumId)
                    out.add(
                        MediaInfo(
                            key = "a$id",
                            id = id,
                            uri = ContentUris.withAppendedId(AudioMedia.EXTERNAL_CONTENT_URI, id),
                            title = c.getString(iTitle)?.takeIf { it.isNotBlank() } ?: "Adsız",
                            artist = artist,
                            album = album,
                            artUri = if (albumId > 0) ContentUris.withAppendedId(ART_BASE, albumId) else null,
                            durationMs = c.getLong(iDur),
                            folderPath = c.getString(iData)?.substringBeforeLast('/', "") ?: "",
                            isVideo = false
                        )
                    )
                }
            }
        }
        return out
    }

    fun loadVideos(ctx: Context): List<MediaInfo> {
        val out = ArrayList<MediaInfo>()
                val proj = arrayOf(VideoMedia._ID, VideoMedia.DISPLAY_NAME, VideoMedia.DURATION, VideoMedia.DATA)
        runCatching {
            ctx.contentResolver.query(
                VideoMedia.EXTERNAL_CONTENT_URI, proj, null, null, "${VideoMedia.DISPLAY_NAME} COLLATE NOCASE ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(VideoMedia._ID)
                val iName = c.getColumnIndexOrThrow(VideoMedia.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(VideoMedia.DURATION)
                val iData = c.getColumnIndexOrThrow(VideoMedia.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val path = c.getString(iData)?.substringBeforeLast('/', "") ?: ""
                    val name = (c.getString(iName) ?: "Video").substringBeforeLast('.')
                    out.add(
                        MediaInfo(
                            key = "v$id",
                            id = id,
                            uri = ContentUris.withAppendedId(VideoMedia.EXTERNAL_CONTENT_URI, id),
                            title = name,
                            artist = path.substringAfterLast('/').ifBlank { "Video" },
                            album = "",
                            artUri = null,
                            durationMs = c.getLong(iDur),
                            folderPath = path,
                            isVideo = true
                        )
                    )
                }
            }
        }
        return out
    }
}
